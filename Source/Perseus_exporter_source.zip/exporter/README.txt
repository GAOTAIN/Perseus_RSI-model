Perseus Live2D exporter

Uses Umamo's open-source native Cubism MOC3 encoder and CMO3 serializer, targeting Cubism 4.2.
Original upstream license and source remain in ../umamo.

Build (JDK 21, from this directory):
  ../gradle-cache/wrapper/dists/gradle-9.6.1-bin/4ticwg1pgcbps2hj28r8so764/gradle-9.6.1/bin/gradle.bat installDist

Run:
  build/install/perseus-exporter/bin/perseus-exporter.bat rig.json output_directory
  Add --no-cmo3 to emit runtime files only.

Manifest:
{
  "name":"Perseus",
  "canvasWidth":1024, "canvasHeight":2048,
  "textureFiles":["atlas.png"],
  "parameters":[{"id":"ParamEyeLOpen","name":"Left eye","min":0,"max":1,"default":1}],
  "layers":[{
    "id":"ArtEyeL", "name":"Left eye", "partId":"PartFace",
    "rect":[100,100,200,100], "grid":[4,2], "uvRect":[0,0,1,1],
    "texturePage":0, "drawOrder":500, "opacity":1,
    "axes":[{"id":"ParamEyeLOpen","keys":[0,1]}],
    "keyforms":[{"coord":[0],"deltas":[...],"opacity":0}, {"coord":[1],"deltas":[...],"opacity":1}]
  }]
}

Coordinates and UVs have a top-left origin. Rectangles are x,y,width,height. UV rectangles
are normalized. Grid values count cells. Vertices are row-major, (ny+1)*(nx+1), with interleaved
x,y. Deltas are canvas pixels relative to the rest vertices. Explicit positions/uvs/indices
arrays replace regular grid construction. keyforms must cover all axis combinations; coord
holds key indices in declared axis order. Axes and keyforms may be omitted for static art.
All paths in textureFiles are relative to the rig JSON. Output file paths cannot escape their
destination. Textures are bundled under textures/. Standard eye blink and lip sync groups
are generated automatically for ParamEyeLOpen, ParamEyeROpen, and ParamMouthOpenY.

Optional sparse additive shape keys on a layer avoid large Cartesian grids:
  "morphs":[{"id":"ParamBreath", "keys":[0,1], "deltas":[null,[...]], "opacityDeltas":[0,0]}]
Each non-neutral delta array has the same length as positions; a null entry means all zeros.
Sorted keys must include neutral value 0. The neutral entry is ignored. Morph parameters
automatically become native Cubism blendshape parameters. A parameter cannot be used in
both regular axes and sparse morphs. Different morphs add together and also add onto any
regular head grid. Opacity deltas are optional and additive, defaulting to zero.
