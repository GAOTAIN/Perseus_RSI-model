import java.io.File
import javax.imageio.ImageIO
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.*
import org.umamo.format.cmo3.Cmo3
import org.umamo.format.moc3.moc.MocVersion
import org.umamo.format.moc3.moc.MocCodec
import org.umamo.format.moc3.encode.MocEncoder
import org.umamo.format.moc3.Moc3
import org.umamo.interop.cmo3.Cmo3Conversion
import org.umamo.interop.moc3.Moc3Sidecars
import org.umamo.runtime.eval.meshGridDefaultDeltas
import org.umamo.runtime.eval.scalarAt
import org.umamo.runtime.model.*

private val json = Json { prettyPrint = true; ignoreUnknownKeys = true }
private fun JsonObject.s(k: String, d: String = "") = (this[k] as? JsonPrimitive)?.content ?: d
private fun JsonObject.f(k: String, d: Float = 0f) = (this[k] as? JsonPrimitive)?.floatOrNull ?: d
private fun JsonObject.i(k: String, d: Int = 0) = (this[k] as? JsonPrimitive)?.intOrNull ?: d
private fun JsonObject.a(k: String) = this[k] as? JsonArray ?: JsonArray(emptyList())
private fun JsonArray.floats() = FloatArray(size) { this[it].jsonPrimitive.float }
private fun JsonArray.ints() = IntArray(size) { this[it].jsonPrimitive.int }
private fun File.under(path: String): File {
    val candidate = resolve(path).canonicalFile
    require(candidate.toPath().startsWith(canonicalFile.toPath())) { "Output path escapes destination: $path" }
    return candidate
}

fun main(args: Array<String>) {
    if (args.getOrNull(0) == "--repack" || args.getOrNull(0) == "--rebake") {
        require(args.size == 3)
        val bytes = File(args[1]).readBytes()
        val rewritten = if (args[0] == "--repack") MocEncoder.repack(MocCodec.read(bytes)) else Moc3.write(Moc3.read(bytes))
        File(args[2]).apply { parentFile.mkdirs(); writeBytes(rewritten) }
        println("Diagnostic ${args[0]} ${bytes.size} -> ${rewritten.size} bytes")
        return
    }
    require(args.size >= 2) { "Usage: exporter <rig.json> <output-directory> [--no-cmo3]" }
    val manifestFile = File(args[0]).canonicalFile
    val input = json.parseToJsonElement(manifestFile.readText(Charsets.UTF_8)).jsonObject
    val output = File(args[1]).canonicalFile.apply { mkdirs() }
    val basename = input.s("name", "Perseus").replace(Regex("[^a-zA-Z0-9_-]"), "_")
    val canvasWidth = input.f("canvasWidth")
    val canvasHeight = input.f("canvasHeight")
    require(canvasWidth > 0f && canvasHeight > 0f)
    val textureFiles = input.a("textureFiles").map { manifestFile.parentFile.resolve(it.jsonPrimitive.content).canonicalFile }
    require(textureFiles.isNotEmpty() && textureFiles.all { it.isFile }) { "Missing texture pages" }
    val layerInputs = input.a("layers").map { it.jsonObject }
    val morphParameterIds = layerInputs.flatMap { layer -> layer.a("morphs").map { it.jsonObject.s("id") } }.toSet()
    val gridParameterIds = layerInputs.flatMap { layer -> layer.a("axes").map { it.jsonObject.s("id") } }.toSet()
    require(morphParameterIds.intersect(gridParameterIds).isEmpty()) { "A parameter cannot mix regular keyforms and sparse blendshape morphs" }
    val parameters = input.a("parameters").map { p ->
        val p = p.jsonObject
        val kind = if (p.s("kind").lowercase() == "blendshape" || p.s("id") in morphParameterIds) ParameterKind.BLEND_SHAPE else ParameterKind.NORMAL
        Parameter(ParameterId(p.s("id")), p.s("name", p.s("id")), p.f("min"), p.f("max", 1f), p.f("default"), kind)
    }
    require(parameters.map { it.id }.distinct().size == parameters.size) { "Duplicate parameter id" }
    val parameterIds = parameters.mapTo(HashSet()) { it.id.raw }
    val defaults = parameters.associate { it.id to it.default }
    val defaultValue: (ParameterId) -> Float = { defaults[it] ?: 0f }
    val partIds = layerInputs.map { it.s("partId", "PartRoot") }.distinct()
    val drawables = layerInputs.mapIndexed { layerIndex, layer ->
        val id = layer.s("id", "ArtMesh${layerIndex + 1}")
        val grid = layer.a("grid")
        val nx = grid.getOrNull(0)?.jsonPrimitive?.int ?: 1
        val ny = grid.getOrNull(1)?.jsonPrimitive?.int ?: 1
        require(nx in 1..100 && ny in 1..100) { "Invalid mesh grid for $id" }
        val rect = layer.a("rect").floats()
        val uv = layer.a("uvRect").takeIf { it.size == 4 }?.floats() ?: floatArrayOf(0f, 0f, 1f, 1f)
        val positions = if (layer["positions"] is JsonArray) layer.a("positions").floats() else {
            require(rect.size == 4) { "rect [x,y,width,height] required for $id" }
            FloatArray((nx + 1) * (ny + 1) * 2) { c ->
                val vertex = c / 2
                if (c % 2 == 0) rect[0] + rect[2] * (vertex % (nx + 1)) / nx else rect[1] + rect[3] * (vertex / (nx + 1)) / ny
            }
        }
        val uvs = if (layer["uvs"] is JsonArray) layer.a("uvs").floats() else FloatArray(positions.size) { c ->
            val vertex = c / 2
            if (c % 2 == 0) uv[0] + uv[2] * (vertex % (nx + 1)) / nx else uv[1] + uv[3] * (vertex / (nx + 1)) / ny
        }
        val indices = if (layer["indices"] is JsonArray) layer.a("indices").ints() else IntArray(nx * ny * 6) { n ->
            val cell = n / 6
            val topLeft = (cell / nx) * (nx + 1) + cell % nx
            when(n % 6) { 0, 3 -> topLeft; 1 -> topLeft + 1; 2, 4 -> topLeft + nx + 2; else -> topLeft + nx + 1 }
        }
        require(positions.size == uvs.size && positions.size % 2 == 0)
        require(indices.size % 3 == 0 && indices.all { it >= 0 && it < positions.size / 2 })
        val axes = layer.a("axes").map { axis ->
            val axis = axis.jsonObject
            require(axis.s("id") in parameterIds) { "Unknown parameter ${axis.s("id")} on $id" }
            KeyformAxis(ParameterId(axis.s("id")), axis.a("keys").floats().also { keys -> require(keys.isNotEmpty() && keys.toList().zipWithNext().all { (a,b) -> a < b }) })
        }
        val forms = layer.a("keyforms").map { it.jsonObject }
        if (axes.isNotEmpty()) require(forms.size == axes.fold(1) { size, axis -> size * axis.keys.size }) { "Incomplete keyform grid on $id" }
        val geometryGrid = forms.takeIf { axes.isNotEmpty() }?.let { forms ->
            KeyformGrid(axes, forms.map { form ->
                val delta = form.a("deltas").takeIf { it.isNotEmpty() }?.floats() ?: FloatArray(positions.size)
                require(delta.size == positions.size && delta.all { it.isFinite() }) { "Invalid deltas on $id" }
                val coord = form.a("coord").ints()
                require(coord.size == axes.size && coord.indices.all { coord[it] in axes[it].keys.indices })
                KeyformCell(coord, MeshDeltaForm(delta))
            })
        }
        val channels = if (forms.any { it["opacity"] != null } && axes.isNotEmpty()) {
            ChannelGrids(mapOf(FormChannel.OPACITY to KeyformGrid(axes, forms.map { form -> KeyformCell(form.a("coord").ints(), ChannelValue.Scalar(form.f("opacity", layer.f("opacity", 1f))) as ChannelValue) })))
        } else ChannelGrids.Empty
        val texturePage = layer.i("texturePage")
        require(texturePage in textureFiles.indices)
        val drawable = Drawable(
            id = DrawableId(id), name = layer.s("name", id), parentDeformerId = null,
            blendMode = BlendMode.Normal,
            maskedBy = layer.a("maskedBy").map { DrawableId(it.jsonPrimitive.content) },
            mesh = DrawableMesh.withLocalEqualToCanvas(positions, uvs, indices),
            geometryGrid = geometryGrid, channelGrids = channels,
            drawOrder = layer.f("drawOrder", (layerIndex + 1).toFloat()), opacity = layer.f("opacity", 1f),
            texturePage = texturePage,
        )
        val referenceDeltas = meshGridDefaultDeltas(drawable, defaultValue) ?: FloatArray(positions.size)
        val referenceOpacity = channels.scalarAt(FormChannel.OPACITY, drawable.opacity, defaultValue)
        val morphs = layer.a("morphs").map { morph ->
            val morph = morph.jsonObject
            val morphId = morph.s("id")
            require(morphId in parameterIds) { "Unknown morph parameter $morphId on $id" }
            val keys = morph.a("keys").floats()
            val neutral = keys.indexOfFirst { it == 0f }
            require(neutral >= 0 && keys.toList().zipWithNext().all { (a,b) -> a < b }) { "Morph $morphId requires sorted keys including neutral 0" }
            val deltas = morph.a("deltas")
            require(deltas.size == keys.size) { "Morph $morphId requires one delta array/null per key" }
            val opacityDeltas = morph.a("opacityDeltas")
            BlendShapeBinding(
                ParameterId(morphId), keys, neutral,
                keys.indices.map { keyIndex ->
                    if (keyIndex == neutral) null else {
                        val delta = (deltas[keyIndex] as? JsonArray)?.floats() ?: FloatArray(positions.size)
                        require(delta.size == positions.size && delta.all { it.isFinite() })
                        MeshForm(
                            FloatArray(positions.size) { referenceDeltas[it] + delta[it] },
                            drawOrder = drawable.drawOrder,
                            opacity = referenceOpacity + (opacityDeltas.getOrNull(keyIndex) as? JsonPrimitive)?.floatOrNull.orZero(),
                        )
                    }
                },
            )
        }
        drawable.copy(blendShapes = morphs)
    }
    require(drawables.map { it.id }.distinct().size == drawables.size) { "Duplicate layer id" }
    val parts = partIds.map { id -> Part(PartId(id), id, layerInputs.mapIndexedNotNull { i, layer -> if (layer.s("partId", "PartRoot") == id) OrgChild.Drawable(drawables[i].id) else null }.reversed()) }
    val puppet = PuppetModel(
        parameters = parameters, parts = parts, deformers = emptyList(), drawables = drawables,
        rootChildren = parts.map { OrgChild.Part(it.id) }, rootPartId = null,
        canvasWidth = canvasWidth, canvasHeight = canvasHeight,
        worldOriginX = canvasWidth / 2, worldOriginZ = -canvasHeight / 2,
        pixelsPerUnit = input.f("pixelsPerUnit", canvasHeight / 2), runtimeTarget = RuntimeTarget.Cubism42,
        parameterTree = parameters.map { ParameterNode.Param(it.id) },
    ).withDerivedRenderRoot()
    val pages = textureFiles.mapIndexed { index, file -> Moc3Sidecars.AtlasPage("textures/texture_${index.toString().padStart(2, '0')}.png", file.readBytes()) }
    // Raw MOC3 shares the canvas top-down convention. Core converts positions and UVs to
    // its public runtime Y-up / V-up convention on revive/update; do not pre-flip either.
    val mocVersion = MocVersion.fromByte(input.i("mocVersion", 4))
    val bundle = Moc3Sidecars.bundle(puppet, basename, mocVersion, pages)
    for (file in bundle.files) output.under(file.name).also {
        it.parentFile.mkdirs()
        it.writeBytes(if (file.name == bundle.mocFileName) withCorrectColorCounts(file.bytes) else file.bytes)
    }
    val model3File = output.under("$basename.model3.json")
    val model3 = json.parseToJsonElement(model3File.readText()).jsonObject.toMutableMap()
    val eyeIds = listOf("ParamEyeLOpen", "ParamEyeROpen").filter { it in parameterIds }
    val lipIds = listOf("ParamMouthOpenY").filter { it in parameterIds }
    model3["Groups"] = buildJsonArray {
        if (eyeIds.isNotEmpty()) add(buildJsonObject { put("Target", "Parameter"); put("Name", "EyeBlink"); put("Ids", JsonArray(eyeIds.map(::JsonPrimitive))) })
        if (lipIds.isNotEmpty()) add(buildJsonObject { put("Target", "Parameter"); put("Name", "LipSync"); put("Ids", JsonArray(lipIds.map(::JsonPrimitive))) })
    }
    model3["Layout"] = buildJsonObject { put("CenterX", 0); put("CenterY", 0); put("Height", 2) }
    model3File.writeText(json.encodeToString(JsonObject(model3)), Charsets.UTF_8)
    println("MOC3: ${output.resolve(bundle.mocFileName)}; ${drawables.size} meshes; ${parameters.size} parameters")
    println("MOC3 notices: ${bundle.report}")
    if ("--no-cmo3" !in args) {
        val cmoPages = textureFiles.map { file ->
            val image = ImageIO.read(file) ?: error("Cannot read ${file.name}")
            Cmo3Conversion.AtlasPage(file.readBytes(), image.width, image.height)
        }
        val converted = Cmo3Conversion.freshCmo3(puppet, cmoPages, drawables.associate { it.id.raw to it.texturePage }, basename, System.currentTimeMillis(), 97)
        output.under("$basename.cmo3").writeBytes(Cmo3.write(converted.model))
        println("CMO3: ${output.resolve("$basename.cmo3")}")
        println("CMO3 notices: ${converted.report}")
    }
}

private fun Float?.orZero(): Float = this ?: 0f

/**
 * Umamo's blend-free v4+ lowering writes color rows but leaves their CountInfo extents at
 * zero. Core's consistency checker correctly rejects that mismatch. Sparse-blend models
 * already set the counts. All rigs emitted here carry explicit per-keyform identity colors.
 */
private fun withCorrectColorCounts(bytes: ByteArray): ByteArray {
    if ((bytes[4].toInt() and 255) < 4) return bytes
    val result = bytes.copyOf()
    val buffer = ByteBuffer.wrap(result).order(ByteOrder.LITTLE_ENDIAN)
    val countInfo = buffer.getInt(64)
    if (buffer.getInt(countInfo + 23 * 4) == 0) {
        val rowCount = (7..9).sumOf { buffer.getInt(countInfo + it * 4) }
        buffer.putInt(countInfo + 23 * 4, rowCount)
        buffer.putInt(countInfo + 24 * 4, rowCount)
    }
    return result
}
