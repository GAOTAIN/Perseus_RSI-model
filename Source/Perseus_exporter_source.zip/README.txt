Perseus RSI model exporter source

This folder contains the driver source and all Umamo source files compiled into it.
No Gradle dependency cache, proprietary Core DLL, or installed example-model artwork is included.

Upstream: https://github.com/umamoorg/umamo
Upstream revision: 521179cfe1a8579c4ac04c778d53b8347bf46a98
Upstream and this linked exporter driver: GNU GPL version 3 (licenses/Umamo-GPL-3.0.txt).
The Gradle wrapper is under the Apache 2.0 license (licenses/Gradle-Apache-2.0.txt).
The original character artwork and exported model data are separate user assets.

Build with JDK 21 (JAVA_HOME must point to that JDK):
  cd exporter
  .\gradlew.bat installDist

The wrapper downloads Gradle 9.6.1, and the build downloads the exact Maven dependencies
listed in build.gradle. A network connection is required for a first build.

Run:
  .\build\install\perseus-exporter\bin\perseus-exporter.bat <rig.json> <output-directory>

See exporter/README.txt for the manifest schema. Input artwork and rig.json are provided
separately in the model source package. The driver emits native Cubism4.2 runtime files
and a CMO3 source. It also repairs Umamo's blend-free v4 color-row count metadata.

Verification on this task used VTube Studio's installed Cubism Core5.0 read-only.
The Core DLL is not redistributed.
